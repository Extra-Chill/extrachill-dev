<?php
/**
 * Stripe Test Key Overrides for Local Development
 *
 * Provides test API keys for Stripe integration when running in local environment.
 * Only active when WP_ENVIRONMENT_TYPE is set to 'local'.
 *
 * @package ExtraChillDev
 * @since 0.2.0
 */

defined( 'ABSPATH' ) || exit;

add_filter( 'extrachill_stripe_secret_key', 'extrachill_dev_stripe_secret_key' );

function extrachill_dev_stripe_secret_key( $key ) {
	if ( ! defined( 'WP_ENVIRONMENT_TYPE' ) || WP_ENVIRONMENT_TYPE !== 'local' ) {
		return $key;
	}
	return 'sk_test_iOOlwq9bCu0vzrTTzXovfxe5';
}

add_filter( 'extrachill_stripe_publishable_key', 'extrachill_dev_stripe_publishable_key' );

function extrachill_dev_stripe_publishable_key( $key ) {
	if ( ! defined( 'WP_ENVIRONMENT_TYPE' ) || WP_ENVIRONMENT_TYPE !== 'local' ) {
		return $key;
	}
	return 'pk_test_VpZXhkZXWROq7GpuX8SBUDa4';
}

add_filter( 'extrachill_stripe_webhook_secret', 'extrachill_dev_stripe_webhook_secret' );

function extrachill_dev_stripe_webhook_secret( $key ) {
	if ( ! defined( 'WP_ENVIRONMENT_TYPE' ) || WP_ENVIRONMENT_TYPE !== 'local' ) {
		return $key;
	}
	// Webhook secret is optional for local testing.
	// Set this if you're using Stripe CLI to forward webhooks locally.
	return '';
}